user_name = input("whis is your name? ")
my_name = "jordan"

if user_name == my_name:
    print ("you have the name as me, or are me?? ")
else:
    quit