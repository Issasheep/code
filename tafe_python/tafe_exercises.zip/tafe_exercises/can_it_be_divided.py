user_input = int(input("put in a number this is divisable with both 5 and 7 \n"))
if user_input % 5 == 0:
    print("got one right! ")
else: 
    print("wrong number \n")

if user_input % 7 == 0:
    print("you got it!")
else:
    print("soo close! \n")
