users_password = input("make a passowrd, any password: ")
user_password_check = input("enter your password here: ")

if users_password == user_password_check:
    print ("password correct")
else:
    print ("password incorrect")